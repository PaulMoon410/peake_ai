from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Simple game state store
game_state = {
    "x": 0,
    "y": 0
}

@app.route("/")
def home():
    return "PeakeCoin MUD backend is running!"

@app.route("/save", methods=["POST"])
def save():
    global game_state
    game_state = request.json
    return jsonify({"status": "saved", "data": game_state})

@app.route("/load", methods=["GET"])
def load():
    return jsonify(game_state)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

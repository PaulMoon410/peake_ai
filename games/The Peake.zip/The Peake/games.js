(function () {
    let player = {
      x: 5,
      y: 5,
      hp: 100,
      stamina: 50,
      inventory: ["Map"],
    };
  
    let map = window.gameMap;
  
    function getLocationKey(x, y) {
      return `${x},${y}`;
    }
  
    function describeLocation() {
      const key = getLocationKey(player.x, player.y);
      return map[key] || "You see nothing of interest.";
    }
  
    function render() {
      document.getElementById("output").innerText = describeLocation();
      document.getElementById("stats").innerText = `HP: ${player.hp}\nStamina: ${player.stamina}`;
      const inventoryList = document.getElementById("inventory");
      inventoryList.innerHTML = "";
      player.inventory.forEach((item) => {
        const li = document.createElement("li");
        li.textContent = item;
        inventoryList.appendChild(li);
      });
    }
  
    window.move = function (direction) {
      let newX = player.x;
      let newY = player.y;
  
      switch (direction) {
        case "n": newY -= 1; break;
        case "s": newY += 1; break;
        case "e": newX += 1; break;
        case "w": newX -= 1; break;
      }
  
      const key = getLocationKey(newX, newY);
      if (map.hasOwnProperty(key)) {
        player.x = newX;
        player.y = newY;
      } else {
        alert("You can't go that way.");
      }
  
      render();
    };
  
    window.saveGame = function () {
      const data = btoa(JSON.stringify(player));
      navigator.clipboard.writeText(data);
      alert("Save code copied to clipboard!");
    };
  
    window.downloadSave = function () {
      const data = btoa(JSON.stringify(player));
      const blob = new Blob([data], { type: "text/plain" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "save.txt";
      link.click();
    };
  
    window.loadGame = function () {
      try {
        const input = document.getElementById("loadInput").value;
        const decoded = atob(input);
        const loaded = JSON.parse(decoded);
        if (loaded.x !== undefined && loaded.y !== undefined) {
          player = loaded;
          render();
          alert("Game loaded!");
        } else {
          throw new Error("Invalid format.");
        }
      } catch (e) {
        alert("Invalid save code.");
      }
    };
  
    render();
  })();
  